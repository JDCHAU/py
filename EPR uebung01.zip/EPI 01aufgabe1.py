#__ Author __ = <s1317331><Jiadong Zhou>
val_1 = int(input("geben Sie eine Ganzzahl ein: ")         """Fehler1"""   
if val_1 // 9 == 0 :   # check if input is divisible by 9  """Fehler2"""
    val_2 = val_1 // 9                                      
     print("Testausgabe", val_2)                           """Fehler3"""
else:
    print("Testausgabe", val_1)
if val_1/val_2 >= 1: # ratio between val_1 and val_2       """Fehler4"""
    print("Verhältis größer 1")                            
else:
    print("val_2 ist größer als val_1")


#Fehler1: ohne Klammer  (SyntaxFehler，statischer Fehler)   
#Fehler2: man checkt , ob es 9 durchbar ist, soll man Modulo benutzen.
#         Und wenn val_1 ein 0 zugeweist wird,ist diese Programm sinnlos. 
#Fehler3: p von print soll auf v von val ausrichten. Es gibt's hier 
#         unnoetige Einrueckung. (StyleFehler)  
#Fehler4: Die Variable val_2 ist nicht definiert.(NameError,statisch)
#         Es darf nicht direckt benutzen.
#         val_2 darf nicht gleich 0 . (ZeroDivisionError dynamisch)
#         Falls val_1 gleich val_2 ist ratio gleich 1.
#         Kein Exception aber Verhältnis ist >=1   
