#__ Author__ =<s1317331><Jiadong Zhou>

# 2 Zahlen eingeben, print die grossere ,dann testen,ob durch 3,5,9

zahl1 = int(input("Geben Sie 1.Zahl ein\n"))
zahl2 = int(input("Geben Sie 2.Zahl ein\n"))
vergleich_zahl1 = zahl1 - zahl2
vergleich_zahl2 = zahl2 - zahl1

#Vorsicht: 135 ist durch 3,5,9 teilbar, Prioritaet von Teilbarkeiten 
#{3,5,9}(aequivalenz zu {5,9})>(3,9)={3,5}>{9}>(5)={3} 
if vergleich_zahl1 >= 0 :
    print(str(zahl1) + " ist die groessere")
    if zahl1 % 3 == 0 and zahl1 % 5 == 0 and zahl1 % 9 == 0 :
        print("ist durch 3 und 5 und 9 teilbar ")
    elif zahl1 % 3 == 0 and zahl1 % 9 == 0:
        print("ist durch 3 und 9 teilbar")
    elif zahl1 % 3 == 0 and zahl1 % 5 == 0 :
        print("ist durch 3 und 5 teilbar")
    elif zahl1 % 9 == 0 : 
        print("ist durch 9 teilbar")
    elif zahl1 % 5 == 0 :
        print("ist durch 5 teilbar")
    elif zahl1 % 3 == 0 :
        print("ist durch 3 teilbar")
    else :
        print("nicht durch 3,5,9,3und5,3und9,3und5und9 teilbar")
  
else :
    print(str(zahl2) +" ist die groessere")
    if  zahl2 % 3 == 0 and zahl2 % 5 == 0 and zahl2 % 9 == 0 :
        print("ist durch 3,5,9 teilbar")
    elif zahl2 % 3 == 0 and zahl2 % 9 == 0:
        print("ist durch 3,9 teilbar")
    elif zahl2 % 3 == 0 and zahl2 % 5 == 0: 
        print("ist durch 3,5 teilbar")
    elif zahl2 % 9 == 0 :
        print("ist durch 9 teilbar")
    elif zahl2 % 5 == 0 :
        print("ist durch 5 teilbar")
    elif zahl2 % 3 == 0 :
        print("ist durch 3 teilbar ") 
    else :
        print("nicht durch 3,5,9,3und5,3und9,3und5und9 teilbar")
#============================================

"""Testfaelle
1.
Geben Sie 1.Zahl ein
120

Geben Sie 2.Zahl ein
110
120 ist die groessere
ist durch 3 und 5 teilbar
==============================================
2.
Geben Sie 1.Zahl ein
10

Geben Sie 2.Zahl ein
15000
15000 ist die groessere
ist durch 3,5 teilbar
==============================================
3.
Geben Sie 1.Zahl ein
13

Geben Sie 2.Zahl ein
7
13 ist die groessere
==============================================
4.
Geben Sie 1.Zahl ein
45

Geben Sie 2.Zahl ein
27
45 ist die groessere
ist durch 3 und 5 und 9 teilbar
"""














