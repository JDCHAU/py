__author__ = "<s1317331><Jiadong Zhou>"
i = 0
while i < 5:
    print(i)
    i += 1
#0 1 2 3 4,zuerst wird i geprueft,ob i <5,falls ja,
#print(i),dann i=i+1.Es wird 4-0+1=5 mal wiederholt.
#====================================================
i = 0
while i < 5:
    i += 1
    print(i)
# 1 2 3 4 5  zuerst wird i geprueft,ob i <5,falls ja,
#i=i+1,print(i). Auch 5 mal wiederholt,print 1 bis 5.
#Also addieren vor print.
#====================================================
for i in range(0, 5):
    print(i)
#0 1 2 3 4 
#range(a,b) i wird b-a mal von a bis b-1 wiederholt. 
#====================================================
a = float(input("Geben Sie eine Zahl ein\n"))
b = 0 
while a != 0.0:
    a = a/2.0
    b += 1
print(b)
    
    
    
    
    
    
    
    
    
    
    