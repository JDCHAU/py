__author__ = "<S1317331><Jiadong Zhou>"

def schachfeld (a,b):                   # i row/line    j column
    for i in range(1,a+1):
        if i % 2 == 0: 
            print("1 ",end = "")      # end should space not nextline 
        else: 
            print("0 ",end = "") 
        for j in range (2,b+1):
            if j % 2 == 0 and i % 2 == 1:   # odd line and even column
                print("1 ",end = "")
            elif j % 2 == 1 and i % 2 == 0: # #even line and odd column
                print("1 ",end = "")
            else:
                print("0 ",end = "" )
        print()
        
zeil = int(input("Geben Sie Zeile ein\n"))
spalte = int(input("Geben Sie Spalte ein\n"))
schachfeld(zeil,spalte)
"""
Testfaelle
Geben Sie Zeile ein
3

Geben Sie Spalte ein
3
0 1 0 
1 0 1 
0 1 0 

Geben Sie Zeile ein
4

Geben Sie Spalte ein
6
0 1 0 1 0 1 
1 0 1 0 1 0 
0 1 0 1 0 1 
1 0 1 0 1 0 

Geben Sie Zeile ein
8

Geben Sie Spalte ein
9
0 1 0 1 0 1 0 1 0 
1 0 1 0 1 0 1 0 1 
0 1 0 1 0 1 0 1 0 
1 0 1 0 1 0 1 0 1 
0 1 0 1 0 1 0 1 0 
1 0 1 0 1 0 1 0 1 
0 1 0 1 0 1 0 1 0 
1 0 1 0 1 0 1 0 1 







"""