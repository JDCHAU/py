__author__ = "<s1317331>,<Jiadong Zhou>"
#Aufgabe 3
def fakulitaet (a):         #a!
    b=1 
    for i in range(1,a+1):  #recursive
        b = b*i
        c = b
        b = c
    print(b)
    return b 
a = 0

summe = 0
li = [1]     # first element in list
while summe <=2.7182818284 :
    a = a+1                 # counter
    jede = 1/fakulitaet(a)
    li.append(jede)        # add 1/factorial at the end of list 
    summe = sum(li)        # summation 
print(a)                   # print count
print(li[::])              #print all element  
# a = 13,e=2.7182818284
"""
1
2
6
24
120
720
5040
40320
362880
3628800
39916800
479001600
6227020800
13
[1, 1.0, 0.5, 0.16666666666666666, 
 0.041666666666666664, 0.008333333333333333, 
 0.001388888888888889, 0.0001984126984126984, 
 2.48015873015873e-05, 2.7557319223985893e-06, 
 2.755731922398589e-07, 2.505210838544172e-08, 
 2.08767569878681e-09, 1.6059043836821613e-10]








"""