__author__ = "<s1317331><Jiadong Zhou>"
# 8*8 Schachfeld
for i in range(1,9):
    if i % 2 == 0: #Zeil(2,4,6,8)
        print("1 ",end = "") # end should be space not nextline.
    else: 
        print("0 ",end = "") # Zeil(1,3,5,7) 
    for j in range (2,9):
        if j % 2 == 0 and i % 2 == 1: # odd line and even column 
            print("1 ",end = "")
        elif j % 2 == 1 and i % 2 == 0: #even line and odd column
            print("1 ",end = "")
        else:
            print("0 ",end = "" )
    print()
"""
Testfaelle
0 1 0 1 0 1 0 1 
1 0 1 0 1 0 1 0 
0 1 0 1 0 1 0 1 
1 0 1 0 1 0 1 0 
0 1 0 1 0 1 0 1 
1 0 1 0 1 0 1 0 
0 1 0 1 0 1 0 1 
1 0 1 0 1 0 1 0 


"""
