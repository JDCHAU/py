
__author__ = "<s1317331><Jiadong Zhou>"


#Document:2 Ganzzahlen a,b, Summe von List[a,a+1...,b] berechnen
#Die vertauschete Eingabe soll gleiche Ergebnis liefern.

def summeberechnen (a,b): 
    i = 1
    summeberechnen_list=[a]    # the first element in list is a
    for i in range(a,b):        
        summeberechnen_list.append(a+1)   # a+i appended at the end of list 
        print(summeberechnen_list[::])    # print from first positon to last positon
        print(sum(summeberechnen_list))   # print summe
        a= a+1
geben1 = int(input("Geben 1. Zahl\n"))  
geben2 = int(input("Geben 2. Zahl\n"))
if geben1 <= geben2 :                 #test which one is bigger 
    summeberechnen (geben1,geben2)    #the first one equalor or lesser than the second one
else:                                 #else 
    summeberechnen(geben2,geben1)

# Testfaelle:
"""
Geben 1. Zahl
2

Geben 2. Zahl
5
[2, 3]
5
[2, 3, 4]
9
[2, 3, 4, 5]
14
=======================
   
Geben 1. Zahl
5

Geben 2. Zahl
3
[3, 4]
7
[3, 4, 5]
12  
=======================
Geben 1. Zahl
20

Geben 2. Zahl
3
[3, 4]
7
[3, 4, 5]
12
[3, 4, 5, 6]
18
[3, 4, 5, 6, 7]
25
[3, 4, 5, 6, 7, 8]
33
[3, 4, 5, 6, 7, 8, 9]
42
[3, 4, 5, 6, 7, 8, 9, 10]
52
[3, 4, 5, 6, 7, 8, 9, 10, 11]
63
[3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
75
[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13]
88
[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14]
102
[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15]
117
[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16]
133
[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17]
150
[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18]
168
[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19]
187
[3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
207





"""     
    
    
   
    